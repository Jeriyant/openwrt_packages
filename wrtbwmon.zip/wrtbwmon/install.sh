opkg update
opkg install *.ipk
/etc/init.d/wrtbwmon enable
/etc/init.d/wrtbwmon start
clear
echo "Silakan Logout dan Masuk Lagi ke LuCI OpenWRT"
echo "Menunya ada di System - Usage"